<link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
@yield('css')
	<link href="{{ asset('cms/vendor/bootstrap-select/dist/css/bootstrap-select.min.css') }}" rel="stylesheet">
    {{-- SweetAler --}}
    <link href="{{ asset('cms/vendor/sweetalert2/dist/sweetalert2.min.css') }}" rel="stylesheet">
    {{-- Toast --}}
    <link rel="stylesheet" href="{{ asset('cms/vendor/toastr/css/toastr.min.css') }}">
    <link href="{{ asset('cms/css/style.css') }}" rel="stylesheet">

