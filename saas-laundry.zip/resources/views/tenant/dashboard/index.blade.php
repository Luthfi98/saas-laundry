@extends('layouts.tenant')

@section('title'){{ $title }}@endsection

@section('content')

<div class="row">
  
</div>

@endsection

