<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <div class="d-flex justify-content-between mb-3">
                            <div>
                                <!-- Add your buttons here -->
                            </div>
                            <div>
                                <?php if($general->canAccess('module-menu-create', true)): ?>
                                    <a href="<?php echo e(route('menus.create')); ?>" class="btn btn-primary btn-sm" title="Create"><span class="fa fa-plus"></span> <?php echo e(__("Add Menu")); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <table class="display table" id="data-table" width="100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Parent</th>
                                    <th>Name</th>
                                    <th>Path</th>
                                    <th>Icon</th>
                                    <th width="105px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<!-- Datatable -->
<link href="<?php echo e(asset('cms/vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Datatable -->
<script src="<?php echo e(asset('cms/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('cms/js/plugins-init/datatables.init.js')); ?>"></script>


<script type="text/javascript">
    $(function () {

      var table = $('#data-table').DataTable({
          processing: true,
          serverSide: true,
          ajax: "<?php echo e(route('menus.index')); ?>",
          columns: [
              {
            data: 'id',
            name: 'id',
            render: function(data, type, row, meta) {
                // Calculate the continuous index across all pages
                var continuousIndex = meta.row + meta.settings._iDisplayStart + 1;
                return continuousIndex;
            }
        },
              {data: 'parent_name', name: 'parent.name', defaultContent : ''},
              {data: 'name', name: 'name'},
              {data: 'path', name: 'path'},
              {data: 'icon', name: 'icon'},
              {data: 'action', name: 'action', orderable: false, searchable: false},
          ],
          language: {
			paginate: {
			   next: '<i class="fa-solid fa-angle-right"></i>',
			  previous: '<i class="fa-solid fa-angle-left"></i>'
			},
		  },
      });

    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\saas-laundry\resources\views/cms/menus/index.blade.php ENDPATH**/ ?>