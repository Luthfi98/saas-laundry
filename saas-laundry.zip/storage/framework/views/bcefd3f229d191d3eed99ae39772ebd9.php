<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-8 col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div>
                        <h3 class="card-title">
                        <a href="<?php echo e(route('quotations.index')); ?>" class="badge bg-primary badge-sm" title="Back to list"><span class="fa fa-arrow-left"></span></a>

                            Quotation <?php echo e($quotation->code); ?></h3>
                    </div>
                    <div>
                        <?php if($general->canAccess('module-sales-quotation-create', true)): ?>
                            <a href="<?php echo e(route('quotations.create')); ?>" class="btn btn-primary btn-sm" title="New Opportunity"><span class="fa fa-plus"></span></a>
                        <?php endif; ?>
                        <?php if($general->canAccess('module-sales-quotation-print', true)): ?>
                            <a href="<?php echo e(route('quotations.create')); ?>" class="btn btn-info btn-sm" title="Print Opportunity"><span class="fa fa-print"></span></a>
                        <?php endif; ?>
                        <?php if($general->canAccess('module-sales-quotation-edit', true)): ?>
                            <a href="<?php echo e(route('quotations.edit', $quotation->id)); ?>" class="btn btn-secondary btn-sm" title="Edit Opportunity"><span class="fa fa-pencil"></span></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <div class="row">
                                <div class="col-4">
                                    <h6>Topic </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($quotation->topic); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Opportunity </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <a href="<?php echo e(route('opportunities.show', $quotation->opportunity_id)); ?>" class="" title="Opportunity <?php echo e($quotation->opportunity->code); ?>"><?php echo e($quotation->opportunity->code); ?></a></h6>
                                </div>

                                <div class="col-4">
                                    <h6>Customer </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($quotation?->customer->fullname); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Sales Rep </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($quotation?->salesRep->fullname); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Quotation Date </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e(date("D, d-m-Y", strtotime($quotation->quotation_date))); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Valid Until </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e(date("D, d-m-Y", strtotime($quotation->valid_until))); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Notes </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($quotation->notes); ?></h6>
                                </div>
                            </div>

                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="row">
                                <div class="col-4">
                                    <h6>Currency </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($quotation->currency); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Total Amount </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: Rp. <?php echo e(number_format($quotation->total_amount)); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Discount </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: Rp. <s><?php echo e(number_format($quotation->discount)); ?></s></h6>
                                </div>

                                <div class="col-4">
                                    <h6>Payment Terms </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($quotation->payment_terms); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Delivery Terms </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($quotation->delivery_terms); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Status </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($quotation->status); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Created At </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e(date('d-m-Y H:i', strtotime($quotation->created_at))); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Updated At </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e(date('d-m-Y H:i', strtotime($quotation->updated_at))); ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive p-2">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th class="text-center"><h6>No</h6></th>
                                <th class="text-left"><h6>Product</h6></th>
                                <th class="text-end"><h6>Quantity</h6></th>
                                <th class="text-end"><h6>Price</h6></th>
                                <th class="text-end"><h6>Total</h6></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $quotation->salesQuotationDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><h6><?php echo e($loop->iteration); ?></h6></td>
                                    <td><h6><?php echo e($item->product_name); ?></h6></td>
                                    <td class="text-end"><h6><?php echo e(number_format($item->quantity)); ?></h6></td>
                                    <td class="text-end"><h6><?php echo e(number_format($item->unit_price)); ?></h6></td>
                                    <td class="text-end"><h6><?php echo e(number_format($item->total_price)); ?></h6></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-end text-bold"><h6>Sub Total</h6></td>
                                <td class="text-end text-bold"><h6><?php echo e(number_format($quotation->total_amount)); ?></h6></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-end text-bold"><h6>Discount</h6></td>
                                <td class="text-end text-bold"><h6><s><?php echo e(number_format($quotation->discount)); ?></s></h6></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-end text-bold"><h6>Grand Total</h6></td>
                                <td class="text-end text-bold"><h6><?php echo e(number_format($quotation->total_amount-$quotation->discount)); ?></h6></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Order</h3>
                            <?php if($general->canAccess('module-sales-order-create', true)): ?>
                                <a href="" class=" btn btn-sm btn-info" title="Create Order From this Quotation"><span class="fa fa-plus"></span> Create Order</a>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/cms/quotations/show.blade.php ENDPATH**/ ?>