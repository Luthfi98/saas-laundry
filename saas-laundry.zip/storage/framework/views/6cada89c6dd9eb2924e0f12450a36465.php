<!--**********************************
    Footer start
***********************************-->
<div class="footer">
    <div class="copyright">
        <p>Copyright © Developed by <a href="https://dexignzone.com/" target="_blank">DexignZone</a> 2023</p>
    </div>
</div>
<!--**********************************
    Footer end
***********************************-->
<?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/partials/footer.blade.php ENDPATH**/ ?>