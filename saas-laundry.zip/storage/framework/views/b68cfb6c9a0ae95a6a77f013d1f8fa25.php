<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-4 col-lg-4">
        <div class="clearfix">
            <div class="card card-bx profile-card author-profile m-b30">
                <div class="card-body">
                    <div class="p-5">
                        <div class="author-profile">
                            <div class="author-media">
                                <img src="<?php echo e($user->image ? url($user->image) : ''); ?>" alt="" id="preview">
                                <button class="upload-link" title="" data-toggle="tooltip" data-placement="right" data-original-title="update">
                                    <i class="fa fa-camera"></i>
                                </button>
                            </div>
                            <div class="author-info">
                                <h6 class="title"> <?php echo e($user->fullname); ?> </h6>
                                <span><?php echo e($user->role? $user->role->name : $currentRole?->name); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="info-list">
                        <ul>
                            <li><span>Username</span><span> <?php echo e($user->username); ?> </span></li>
                            <li><span>Fullname</span><span> <?php echo e($user->fullname); ?> </span></li>
                            <li><span>Email</span><span> <?php echo e($user->email); ?> </span></li>
                            <li><span>Phone</span><span> <?php echo e($user->phone); ?> </span></li>
                        </ul>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="input-group mb-3">
                        <div class="form-control text-center bg-white">Change Role</div>
                    </div>
                    <div class="input-group">
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6">

                            <?php
                            $select = $currentRole?->id == $role->role->id ? 'bg-primary text-white disabled' : 'bg-white text-primary btn-outline-primary';
                            ?>
                            <form id="role-form-<?php echo e($role->role->id); ?>" action="<?php echo e(route('profile.change', $role->role->id)); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <button class="btn btn-block <?php echo e($select); ?>" type="button" onclick="showConfirmChangeRole(<?php echo e($role->role->id); ?>)" title="Change to Role <?php echo e($role->role->name); ?>">
                                <?php echo e($role->role->name); ?>

                            </button>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-8 col-lg-8">
        <div class="card profile-card card-bx m-b30">
            <div class="card-header">
                <h6 class="title">Account setup</h6>
            </div>
            <form class="profile-form" method="POST" action="<?php echo e(route('profile.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-6 m-b30">
                            <label class="form-label">Fullname</label>
                            <input type="text" class="form-control" name="fullname" id="fullname" value="<?php echo e($user->fullname); ?>">
                        </div>
                        <div class="col-sm-6 m-b30">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" id="username" value="<?php echo e($user->username); ?>">
                        </div>
                        <div class="col-sm-6 m-b30">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="email" value="<?php echo e($user->email); ?>">
                        </div>
                        <div class="col-sm-6 m-b30">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control" name="phone" id="phone" value="<?php echo e($user->phone); ?>">
                        </div>
                        <div class="col-sm-6 m-b30">
                            <label class="form-label">Default Role</label>
                            <select class="default-select form-control" name="default_role" id="default_role">
                                <option  data-display="Select" value="">Please select</option>
                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->role->id); ?>" <?php echo e($user->default_role == $role->role->id ? 'selected' : ''); ?>><?php echo e($role->role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <input type="file" class="update-flie" id="image" name="image" hidden>

                <div class="card-footer">
                    <button class="btn btn-primary">UPDATE</button>
                    <a href="page-register.html" class="btn-link">Forgot your password?</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(".upload-link").click(function(){
        $('#image').click();
        // console.log(input.files,input.files[0])
    })

    $('#image').on('change', function() {
    var input = this;

    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function(e) {
        // Update the source of the preview image with the selected image
        $('#preview').attr('src', e.target.result);
      };

      reader.readAsDataURL(input.files[0]);
    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/cms/profiles/index.blade.php ENDPATH**/ ?>