<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="nestable">
                    <div class="dd" id="nestable">
                        <ol class="dd-list">
                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="dd-item" data-id="<?php echo e($menu->id); ?>">
                                    <div class="dd-handle"><span class="<?php echo e($menu->icon); ?>"></span> <?php echo e($menu->name); ?>

                                        
                                    </div>
                                    <?php if($menu->child->count() > 0): ?>
                                        <ol class="dd-list">
                                            <?php $__currentLoopData = $menu->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="dd-item" data-id="<?php echo e($childMenu->id); ?>">
                                                    <div class="dd-handle"><span class="<?php echo e($childMenu->icon); ?>"></span> <?php echo e($childMenu->name); ?></div>
                                                    <?php if($childMenu->child->count() > 0): ?>
                                                        <ol class="dd-list">
                                                            <?php $__currentLoopData = $childMenu->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandchildMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li class="dd-item" data-id="<?php echo e($grandchildMenu->id); ?>">
                                                                    <div class="dd-handle"><span class="<?php echo e($grandchildMenu->icon); ?>"></span> <?php echo e($grandchildMenu->name); ?></div>
                                                                    <!-- Repeat this pattern for additional levels -->
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ol>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<!-- Nestable -->
<link href="<?php echo e(asset('cms/vendor/nestable2/css/jquery.nestable.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<!-- Nestable -->
<script src="<?php echo e(asset('cms/vendor/nestable2/js/jquery.nestable.min.js')); ?>"></script>
<script>
     $("#nestable").nestable({
            group: 1,
            maxDepth: 3
        }).on('change', function() {
    // Mengumpulkan data tata letak yang diperbarui
    var updatedData = $(this).nestable('serialize');
    var formData = {
        data: updatedData,
        _token: '<?php echo e(csrf_token()); ?>' // Include CSRF token for Laravel
    };
    $.ajax({
        type: 'POST',
        url: '<?php echo e(route("menus.sorting.store")); ?>',
        data: formData,
        // contentType: 'application/json',
        success: function(response) {
            toastSuccess(response.message)

        },
        error: function(error) {
            // Callback jika terjadi kesalahan saat pengiriman
            console.error('Terjadi kesalahan:', error);
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\saas-laundry\resources\views/cms/menus/sorting.blade.php ENDPATH**/ ?>