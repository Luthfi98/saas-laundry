<?php
    $general = new GeneralHelper;
    $setting = $general->getSetting();
?>
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>

<body class="vh-100">
	<div class="page-wraper">

		<!-- Content -->
		<div class="browse-job login-style3">
			<!-- Coming Soon -->
            <?php echo $__env->yieldContent('content'); ?>
			<!-- Full Blog Page Contant -->
		</div>
		<!-- Content END-->
	</div>

<!--**********************************
	Scripts
***********************************-->
<!-- Required vendors -->
<?php echo $__env->make('partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(session('success')): ?>
<script>
    toastSuccess("<?php echo e(session('success')); ?>");
</script>
<?php elseif(session('warning')): ?>
<script>
    toastWarning("<?php echo e(session('warning')); ?>");
</script>
<?php endif; ?>
</body>
</html>
<?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/layouts/auth.blade.php ENDPATH**/ ?>