<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                          <button onclick="clicknav()" class="nav-link active" id="data-tab" data-bs-toggle="tab" data-bs-target="#data" type="button" role="tab" aria-controls="data" aria-selected="true">Data</button>
                        </li>
                        <li class="nav-item" role="presentation">
                          <button onclick="clicknav()" class="nav-link" id="product-tab" data-bs-toggle="tab" data-bs-target="#product" type="button" role="tab" aria-controls="product" aria-selected="false">Product</button>
                        </li>
                      </ul>
                      <form method="POST" action="<?php echo e(route('quotations.update', $quotation->id)); ?>">
                        <input type="hidden" name="id" value="<?php echo e($quotation->id); ?>" id="id">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                      <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="data" role="tabpanel" aria-labelledby="data-tab">
                            <div class="mt-3">

                                <div class="mb-3">
                                    <label for="code" class="form-label">Code</label>
                                    <input type="text" class="form-control" id="code" name="code" value="<?php echo e(old('code', $quotation->code)); ?>" readonly>
                                </div>

                                <div class="mb-3">
                                    <label for="opportunity_id" class="form-label">Opportunity</label>
                                    <input type="text" class="form-control" id="opportunity_id" name="opportunity_id" value="<?php echo e(old('opportunity_id', $quotation->opportunity->code)); ?>" readonly>
                                </div>

                                <div class="mb-3">
                                    <label for="customer_id" class="form-label">Customer</label>
                                    <select class="form-select" id="customer_id" name="customer_id" required>
                                        
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>" <?php echo e($quotation->customer_id == $customer->id ? 'selected' : ''); ?>><?php echo e($customer->fullname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="sales_rep_id" class="form-label">Sales Representative</label>
                                    <select class="form-select" id="sales_rep_id" name="sales_rep_id" required>
                                        
                                        <?php $__currentLoopData = $salesReps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales_rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($sales_rep->id); ?>" <?php echo e($quotation->sales_rep_id == $sales_rep->id ? 'selected' : ''); ?>><?php echo e($sales_rep->fullname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['sales_rep_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="quotation_date" class="form-label">Quotation Date</label>
                                    <input type="date" class="form-control" id="quotation_date" name="quotation_date" value="<?php echo e(old('quotation_date', $quotation->quotation_date)); ?>" required>
                                    <?php $__errorArgs = ['quotation_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="valid_until" class="form-label">Valid Until</label>
                                    <input type="date" class="form-control" id="valid_until" name="valid_until" value="<?php echo e(old('valid_until', $quotation->valid_until)); ?>" required>
                                    <?php $__errorArgs = ['valid_until'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="currency" class="form-label">Currency</label>
                                    <input type="text" class="form-control" id="currency" name="currency" value="<?php echo e(old('currency', $quotation->currency)); ?>" required>
                                    <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="total_amount" class="form-label">Total Amount</label>
                                    <input type="number" step="0.01" class="form-control" id="total_amount" name="total_amount" value="<?php echo e(old('total_amount', $quotation->total_amount)); ?>" required>
                                    <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="discount" class="form-label">Discount</label>
                                    <input type="number" step="0.01" class="form-control" id="discount" name="discount" value="<?php echo e(old('discount', $quotation->discount)); ?>">
                                    <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="payment_terms" class="form-label">Payment Terms</label>
                                    <textarea class="form-control" id="payment_terms" name="payment_terms" required><?php echo e(old('payment_terms', $quotation->payment_terms)); ?></textarea>
                                    <?php $__errorArgs = ['payment_terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="delivery_terms" class="form-label">Delivery Terms</label>
                                    <textarea class="form-control" id="delivery_terms" name="delivery_terms" required><?php echo e(old('delivery_terms', $quotation->delivery_terms)); ?></textarea>
                                    <?php $__errorArgs = ['delivery_terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <?php $__currentLoopData = ['Draft', 'Sent', 'Approved', 'Rejected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status); ?>" <?php echo e($quotation->status == $status ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="notes" class="form-label">Notes</label>
                                    <textarea class="form-control" id="notes" name="notes"><?php echo e(old('notes', $quotation->notes)); ?></textarea>
                                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="mt-3">
                                    <a href="<?php echo e(route('quotations.index')); ?>" class="btn btn-secondary"><?php echo e(__('Back')); ?></a>
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="product" role="tabpanel" aria-labelledby="product-tab">
                            <table class="table mt-3" width="100%">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Product Name</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                        <th></th>
                                    </tr>
                                    <tr>
                                        <td>
                                            <input type="hidden" name="product_id" id="product_id">
                                            <input id="product_search" name="product_search" class="form-control input-autocomplete">
                                        </td>
                                        <td>
                                            <input id="product_name" name="product_name" class="form-control">
                                        </td>
                                        <td>
                                            <input id="quantity" name="quantity" value="1" type="number" min="0" class="form-control">
                                        </td>
                                        <td>
                                            <input id="unit_price" name="unit_price" value="0" type="number" min="0" class="form-control">
                                        </td>
                                        <td>
                                            <input id="total_price" name="total_price" value="0" type="number" readonly min="0" class="form-control">
                                        </td>
                                        <td width="105px"><button type="button" class="badge badge-sm bg-primary" onclick="addProduct()"><i class="fa fa-plus"></i></button></td>

                                    </tr>
                                </thead>
                                <tbody id="product_list">
                                    <?php
                                        // dd($quotation->salesQuotationDetails())
                                    ?>
                                    <?php $__currentLoopData = $quotation->salesQuotationDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                            <td><?php echo e($product?->product->name); ?></td>
                                            <td><?php echo e($product->product_name); ?></td>
                                            <td class="text-end"><?php echo e(number_format($product->quantity, 2)); ?></td>
                                            <td class="text-end"><?php echo e(number_format($product->unit_price, 2)); ?></td>
                                            <td class="text-end"><?php echo e(number_format($product->total_price, 2)); ?></td>
                                            <td width="105px">
                                                <button type="button" class="badge badge-sm bg-danger" onclick="swalConfirm(<?php echo e($product->id); ?>)"><i class="fa fa-trash"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                      </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .ui-menu .ui-menu-item {
			padding: 8px;
			cursor: pointer;
		}

		.ui-menu .ui-menu-item:hover {
			background-color: #f0f0f0;
			color: #000;
		}

		.ui-state-focus {
			background-color: #007bff;
			color: white;
		}
</style>
<link rel="stylesheet" href="<?php echo e(asset('cms/vendor/select2/css/select2.min.css')); ?> ">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.14.1/themes/base/jquery-ui.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>

<script src="<?php echo e(asset('cms/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('cms/vendor/select2/js/select2.full.min.js')); ?>"></script>
<script src="https://code.jquery.com/ui/1.14.1/jquery-ui.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        clicknav(true);
    })
    $(".select2").select2();
    $('.input-autocomplete').autocomplete({
        source: function(request, response) {
            getProduct(request, response);
        },
        minLength: 2,
        select: function(event, ui) {
            $("#product_id").val(ui.item.id);
            $("#product_name").val(ui.item.label);
            $("#unit_price").val(ui.item.price);
            $("#quantity").attr('max', ui.item.stock);
            countTotal();
        }
    });

    $("#quantity, #unit_price").on("change", function() {
        countTotal();
    });

    function countTotal()
    {
        var total = 0;
        var price = $("#unit_price").val()
        var quantity = $("#quantity").val()

        total = price * quantity;

        $("#total_price").val(total);
    }

    function getProduct(request, response){
        $.ajax({
            url: `<?php echo e(route('products.lists')); ?>`,
            dataType: 'json',
            data: {
                search: request.term,
            },
            success: function(data) {
                response($.map(data, function(item) {
                    return { label: item.text, value: item.label, id: item.id, price: item.price, stock: item.stock };
                }));
            }
        });
    }

    function addProduct()
    {
        var product_id = $("#product_id").val();
        var product_name = $("#product_name").val();
        var quantity = $("#quantity").val();
        var unit_price = $("#unit_price").val();
        var total_price = $("#total_price").val();
        var id = $("#id").val();

        $.ajax({
            url: `<?php echo e(route('quotations.storeProduct')); ?>`,
            type: 'POST',
            data: {
                product_id: product_id,
                product_name: product_name,
                quantity: quantity,
                unit_price: unit_price,
                total_price: total_price,
                quotation_id: id,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                $('.is-invalid').removeClass('is-invalid');
                $('.invalid-feedback').remove();
                $("#product_id").val('')
                $("#product_name").val('')
                $("#product_search").val('')
                $("#quantity").val(1)
                $("#unit_price").val(0)
                $("#total_price").val(0)
                $("#product_list").html(response.html);
                toastSuccess(response.message, 500);
            },
            error: function(xhr) {
                var errors = xhr.responseJSON;
                console.log(errors);
                $('.is-invalid').removeClass('is-invalid');
                $('.invalid-feedback').remove();

                $.each(errors, function(key, value) {
                    var input = $('[name="' + key + '"]');
                    input.addClass('is-invalid');
                    input.after('<div class="invalid-feedback">' + value[0] + '</div>');
                });
            }
        });
    }

    function deleteData(id) {
        $.ajax({
            url: "<?php echo e(route('quotations.destroyProduct', '')); ?>/" + id,
            type: "DELETE",
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                _method: "DELETE"
            },
            success: function(response) {
                if (response.success) {
                    $('#product_list').html(response.html);
                    toastSuccess(response.message);
                } else {
                    toastWarning(response.message);

                }
            },
            error: function(xhr) {
                toastWarning('Something went wrong!');
            }
        });
    }
    function clicknav(isNew = false) {
        var navContainer = $("#myTab");
        var activeElement;
        var opportunityId = $("#opportunity_id").val();

        if (isNew) {
            var oldCookie = $.cookie(`activeTabs${opportunityId}`);
            if (oldCookie) {
                activeElement = navContainer.find(`button[data-bs-target="${oldCookie}"]`);
            }
            if (!activeElement || activeElement.length === 0) {
                activeElement = navContainer.find(`button[data-bs-target="#data"]`);
            }
        } else {
            activeElement = navContainer.find("button.active");
            if (!activeElement || activeElement.length === 0) {
                activeElement = navContainer.find(`button[data-bs-target="#data"]`);
            }
        }

        if (activeElement.length > 0) {
            navContainer.find("button").removeClass("active show");
            $(".tab-content .tab-pane").removeClass("active show");

            activeElement.addClass("active show");
            var targetPane = $(activeElement.attr("data-bs-target"));
            if (targetPane.length > 0) {
                targetPane.addClass("active show");
            }

            if (!isNew) {
                $.cookie(`activeTabs${opportunityId}`, activeElement.attr("data-bs-target"));
            }
        }
    }

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/cms/quotations/edit.blade.php ENDPATH**/ ?>