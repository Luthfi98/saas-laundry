<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <div class="d-flex justify-content-between mb-3">
                            <div>
                                <!-- Add your buttons here -->
                            </div>
                            <div>
                                <?php if($general->canAccess('module-sales-opportunity-create', true)): ?>
                                    <a href="<?php echo e(route('opportunities.create')); ?>" class="btn btn-primary btn-sm" title="Create"><span class="fa fa-plus"></span> <?php echo e(__("Add Opprotunity")); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <table class="display table" id="data-table" width="100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Sales</th>
                                    <th>Customer</th>
                                    <th>Code</th>
                                    <th>Topic</th>
                                    <th>Source</th>
                                    <th>expected_revenue</th>
                                    <th>Probability</th>
                                    <th>Status</th>
                                    <th width="105px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<!-- Datatable -->
<link href="<?php echo e(asset('cms/vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Datatable -->
<script src="<?php echo e(asset('cms/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('cms/js/plugins-init/datatables.init.js')); ?>"></script>


<script type="text/javascript">
    $(function () {

      var table = $('#data-table').DataTable({
          processing: true,
          serverSide: true,
          ajax: "<?php echo e(route('opportunities.index')); ?>",
          columns: [
              {
            data: 'id',
            name: 'id', orderable: false,
            render: function(data, type, row, meta) {
                // Calculate the continuous index across all pages
                var continuousIndex = meta.row + meta.settings._iDisplayStart + 1;
                return continuousIndex;
            }
        },
              {data: 'sales_rep_name', name: 'sales_reps.fullname'},
              {data: 'customer_name', name: 'customers.fullname'},
              {data: 'code', name: 'code'},
              {data: 'topic', name: 'topic'},
              {data: 'source', name: 'source'},
              {data: 'expected_revenue', name: 'expected_revenue', className: 'text-end'},
              {data: 'probability', name: 'probability', className: 'text-center'},
              {data: 'status', name: 'status'},
              {data: 'action', name: 'action', orderable: false, searchable: false, className: 'text-center'},
          ],
          language: {
			paginate: {
			   next: '<i class="fa-solid fa-angle-right"></i>',
			  previous: '<i class="fa-solid fa-angle-left"></i>'
			},
		  },
      });

    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\custom-rbac-laravel\resources\views/cms/opportunities/index.blade.php ENDPATH**/ ?>