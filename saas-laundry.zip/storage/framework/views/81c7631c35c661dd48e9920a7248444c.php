

<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <div class="d-flex justify-content-between mb-3">
                        <div>
                            <!-- Add your buttons here -->
                        </div>
                        <div>
                            <?php if($general->canAccess('module-transaction-tenant-create', true)): ?>
                            <a href="<?php echo e(route('tenant.transactions.create', ['code' => request()->route('code')])); ?>" class="btn btn-primary btn-sm" title="Create">
                                <span class="fa fa-plus"></span> Add Transaction
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <table class="display table" id="data-table" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Invoice</th>
                                <th>Code</th>
                                <th>Customer</th>
                                <th>Branch</th>
                                <th>User</th>
                                <th>Date</th>
                                <th>Pickup Date</th>
                                <th>Status</th>
                                <th>Total</th>
                                <th>Paid</th>
                                <th width="105px">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<!-- Datatable -->
<link href="<?php echo e(asset('cms/vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Datatable -->
<script src="<?php echo e(asset('cms/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('cms/js/plugins-init/datatables.init.js')); ?>"></script>

<script type="text/javascript">
    $(function () {
        var table = $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('tenant.transactions.index', ['code' => request()->route('code')])); ?>",
            columns: [
                {
                    data: 'id',
                    name: 'id',
                    orderable: false,
                    render: function(data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                },
                {data: 'invoice_number', name: 'invoice_number'},
                {data: 'code', name: 'code'},
                {data: 'customer_name', name: 'customer.name'},
                {data: 'branch_name', name: 'branch.name'},
                {data: 'user_name', name: 'user.name'},
                {data: 'transaction_date', name: 'transaction_date', render: function(data) {
                    return moment(data).format('DD/MM/YYYY');
                }},
                {data: 'pickup_date', name: 'pickup_date', render: function(data) {
                    return data ? moment(data).format('DD/MM/YYYY') : '-';
                }},
                {data: 'status_badge', name: 'status'},
                {data: 'total', name: 'total', render: function(data) {
                    return 'Rp ' + parseFloat(data).toLocaleString('id-ID');
                }},
                {data: 'paid', name: 'paid', render: function(data) {
                    return 'Rp ' + parseFloat(data).toLocaleString('id-ID');
                }},
                {data: 'action', name: 'action', orderable: false, searchable: false, className: 'text-center'},
            ],
            language: {
                paginate: {
                    next: '<i class="fa-solid fa-angle-right"></i>',
                    previous: '<i class="fa-solid fa-angle-left"></i>'
                },
            },
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.tenant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\saas-laundry\resources\views/tenant/transactions/index.blade.php ENDPATH**/ ?>