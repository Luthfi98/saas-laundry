<link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
<?php echo $__env->yieldContent('css'); ?>
	<link href="<?php echo e(asset('cms/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(asset('cms/vendor/sweetalert2/dist/sweetalert2.min.css')); ?>" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('cms/vendor/toastr/css/toastr.min.css')); ?>">
    <link href="<?php echo e(asset('cms/css/style.css')); ?>" rel="stylesheet">

<?php /**PATH F:\laragon\www\saas-laundry\resources\views/partials/css.blade.php ENDPATH**/ ?>