<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('roles.update', $role->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group mt-3">
                            <label for="name">Name:</label>
                            <input type="text" name="name" id="name" value="<?php echo e(old('name', $role->name)); ?>" placeholder="Enter role name" class="form-control" required>
                        </div>

                        <div class="form-group mt-3">
                            <label for="description">Description:</label>
                            <textarea name="description" class="form-control" id="description" cols="30" rows="10" placeholder="Enter role description"><?php echo e(old('description', $role->description)); ?></textarea>
                        </div>

                        <div class="mt-3">
                            <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary"><?php echo e(__('Back')); ?></a>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/cms/roles/edit.blade.php ENDPATH**/ ?>