<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-8 col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div>
                        <h3 class="card-title">
                        <a href="<?php echo e(route('opportunities.index')); ?>" class="badge bg-primary badge-sm" title="Back to list"><span class="fa fa-arrow-left"></span></a>

                            Opportunity <?php echo e($opportunity->code); ?></h3>
                    </div>
                    <div>
                        <?php if($general->canAccess('module-sales-opportunity-create', true)): ?>
                            <a href="<?php echo e(route('opportunities.create')); ?>" class="btn btn-primary btn-sm" title="New Opportunity"><span class="fa fa-plus"></span></a>
                        <?php endif; ?>
                        <?php if($general->canAccess('module-sales-opportunity-edit', true)): ?>
                            <a href="<?php echo e(route('opportunities.edit', $opportunity->id)); ?>" class="btn btn-secondary btn-sm" title="Edit Opportunity"><span class="fa fa-pencil"></span></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <div class="row">
                                <div class="col-4">
                                    <h6>Topic </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($opportunity->topic); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Source </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($opportunity->source); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Customer </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($opportunity->customer_id); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Sales Rep </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($opportunity->sales_rep_id); ?></h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="row">
                                <div class="col-4">
                                    <h6>Expected Revenue </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: Rp. <?php echo e(number_format($opportunity->expected_revenue)); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Probability </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($opportunity->probability); ?> %</h6>
                                </div>
                                <div class="col-4">
                                    <h6>Status </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e($opportunity->status); ?></h6>
                                </div>
                                <div class="col-4">
                                    <h6>Created At </h6>
                                </div>
                                <div class="col-8">
                                    <h6>: <?php echo e(date('d-m-Y H:i', strtotime($opportunity->created_at))); ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Quotation</h3>
                            <?php if($general->canAccess('module-sales-quotation-create', true)): ?>
                                <a href="../quotations/opportunity-to-quotation/<?php echo e($opportunity->id); ?>" class=" btn btn-sm btn-info" title="Create Quotation From this Opportunity"><span class="fa fa-plus"></span> Create Quotation</a>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/cms/opportunities/show.blade.php ENDPATH**/ ?>