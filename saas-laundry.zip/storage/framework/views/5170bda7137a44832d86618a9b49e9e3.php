<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xl-4 col-xxl-4 col-lg-4 col-md-6 col-12">
        <div class="row">
            <div class="col-xl-12">
                <div class="card my-calendar">
                    <div class="card-body schedules-cal p-2">
                        <div class="events">
                            <h6>Monitoring Setting</h6>
                            <div class="dz-scroll event-scroll" style="height: 250px !important">
                                <div class="event-media">
                                    <div class="d-flex align-items-center">
                                        <div class="event-box">
                                            <br>
                                            <h5 class="mb-0"><?php echo e($permissions); ?></h5>
                                        </div>
                                        <div class="event-data ms-2">
                                            <h5 class="mb-0"><a target="_BLANK" href="<?php echo e(route('permissions.index')); ?>">Total Permissions</a></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="event-media">
                                    <div class="d-flex align-items-center">
                                        <div class="event-box">
                                            <br>
                                            <h5 class="mb-0"><?php echo e($roles); ?></h5>
                                        </div>
                                        <div class="event-data ms-2">
                                            <h5 class="mb-0"><a target="_BLANK" href="<?php echo e(route('roles.index')); ?>">Total Role</a></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="event-media">
                                    <div class="d-flex align-items-center">
                                        <div class="event-box">
                                            <br>
                                            <h5 class="mb-0"><?php echo e($users); ?></h5>
                                        </div>
                                        <div class="event-data ms-2">
                                            <h5 class="mb-0"><a target="_BLANK" href="<?php echo e(route('users.index')); ?>">Total Users</a></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="event-media">
                                    <div class="d-flex align-items-center">
                                        <div class="event-box">
                                            <br>
                                            <h5 class="mb-0"><?php echo e($menus); ?></h5>
                                        </div>
                                        <div class="event-data ms-2">
                                            <h5 class="mb-0"><a target="_BLANK" href="<?php echo e(route('menus.index')); ?>">Total Menus</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-8 col-md-6 col-12">
        <div class="card overflow-hidden">
            <div class="card-header border-1 pb-3 flex-wrap">
                <h4 class="heading mb-3">Monitoring Activities</h4>
                <div>
                    <a href="<?php echo e(route('report-activity-user')); ?>" class="btn btn-sm btn-primary">View All Activities</a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive active-projects">
                <table class="table" width="100%">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>User</th>
                            <th>IP Address</th>
                            <th>Type</th>
                            <th>URL</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($activity->user?->fullname); ?></td>
                                <td><?php echo e($activity->ip); ?></td>
                                <td><?php echo e($activity->type); ?></td>
                                <td><?php echo e($activity->url); ?></td>
                                <td><?php echo e(date('d-m-Y H:i:s', strtotime($activity->created_at))); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/cms/dashboard.blade.php ENDPATH**/ ?>