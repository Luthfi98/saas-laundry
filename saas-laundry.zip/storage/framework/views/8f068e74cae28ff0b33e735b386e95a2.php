<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="form-group mt-3">
                    <label for="role"><b>Name </b>:</label>
                    <span> <?php echo e($role->name); ?> </span>
                </div>
                <div class="form-group mt-3">
                    <label for="role"><b>Role Description</b>:</label>
                    <span> <?php echo e($role->description); ?> </span>
                </div>
                <hr>
                <label for="">Assigned for Permissions</label>
                <br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="all" value="all" id="select-all">
                    <label class="form-check-label" for="select-all" id="text-is-label">Select All</label>
                </div>
                <form action="<?php echo e(route('roles.storePermission')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($role->id); ?>">
                    <table class="table table-bordered"  width="100%">
                        <thead>
                            <tr>
                                <th width="20%">Menu</th>
                                <th>Permissions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><span><?php echo e($menu['name']); ?></span></td>
                                    <td>
                                        <div class="d-flex flex-wrap">
                                            <?php $__currentLoopData = $menu['permissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mr-2 mb-2">
                                                    <?php
                                                        $checked = $role->permissions->contains('permission_id', $permission['id']) ? 'checked' : '';
                                                        $name = str_replace($menu['module'].'-', '', $permission['name']);
                                                    ?>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input permission" <?php echo e($checked); ?> type="checkbox" name="permissions[]" value="<?php echo e($permission['id']); ?>" id="permissions-<?php echo e($permission['id']); ?>">
                                                        <label class="form-check-label" for="permissions-<?php echo e($permission['id']); ?>" id="text-is-label"><?php echo e(ucfirst($name)); ?></label>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </td>
                                </tr>
                                <?php $__currentLoopData = $menu['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><span style="margin-left: 20px !important"><?php echo e($submenu['name']); ?></span></td>
                                    <td>
                                        <div class="d-flex flex-wrap">
                                            <?php $__currentLoopData = $submenu['permissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mr-2 mb-2">
                                                    <?php
                                                        $checked = $role->permissions->contains('permission_id', $permission['id']) ? 'checked' : '';
                                                        $name = str_replace($submenu['module'].'-', '', $permission['name']);
                                                    ?>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input permission" <?php echo e($checked); ?> type="checkbox" name="permissions[]" value="<?php echo e($permission['id']); ?>" id="permissions-<?php echo e($permission['id']); ?>">
                                                        <label class="form-check-label" for="permissions-<?php echo e($permission['id']); ?>" id="text-is-label"><?php echo e(ucfirst($name)); ?></label>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </td>
                                </tr>
                                    <?php $__currentLoopData = $submenu['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsubmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span style="margin-left: 40px !important"><?php echo e($subsubmenu['name']); ?></span></td>
                                        <td>
                                            <div class="d-flex flex-wrap">
                                                <?php $__currentLoopData = $subsubmenu['permissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="mr-2 mb-2">
                                                        <?php
                                                            $checked = $role->permissions->contains('permission_id', $permission['id']) ? 'checked' : '';
                                                            $name = str_replace($subsubmenu['module'].'-', '', $permission['name']);
                                                        ?>
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input permission" <?php echo e($checked); ?> type="checkbox" name="permissions[]" value="<?php echo e($permission['id']); ?>" id="permissions-<?php echo e($permission['id']); ?>">
                                                            <label class="form-check-label" for="permissions-<?php echo e($permission['id']); ?>" id="text-is-label"><?php echo e(ucfirst($name)); ?></label>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                    <hr>
                    <div class="row mt-3">
                        <label for="">Assigned For User:</label>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-auto">
                                <?php
                                    $checked = $role->users->contains('user_id', $item['id']) ? 'checked' : '';
                                ?>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" <?php echo e($checked); ?> name="users[]" value="<?php echo e($item->id); ?>" id="users-<?php echo e($item->id); ?>">
                                    <label class="form-check-label" for="users-<?php echo e($item->id); ?>" id="text-is-label"><?php echo e($item->fullname); ?></label>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <a href="<?php echo e(route('roles.index')); ?>" class="btn mt-3 btn-secondary"> <?php echo e(__("Back")); ?> </a>
                    <button class="mt-3 btn btn-primary" type="submit"> <?php echo e(__("Save")); ?> </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    checkedAll()
    $('#select-all').on('change', function() {
        $('.permission').prop('checked', $(this).prop('checked'));
    });

    $('body').on('change', '.permission', function() {
        checkedAll()
      });

      function checkedAll()
      {
            if ($('.permission:checked').length === $('.permission').length) {
                $('#select-all').prop('checked', true);
            } else {
                $('#select-all').prop('checked', false);
            }
      }

</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\saas-laundry\resources\views/cms/roles/permission.blade.php ENDPATH**/ ?>