
<!-- PAGE TITLE HERE -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="">
<meta name="author" content="">
<meta name="robots" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?php echo e($setting->description); ?>">
<meta property="og:title" content="<?php echo e($setting->description); ?>">
<meta property="og:description" content="<?php echo e($setting->description); ?>">
<meta property="og:image" content="https://yeshadmin.dexignzone.com/xhtml/social-image.png">
<meta name="format-detection" content="telephone=no">
<title><?php echo e($setting->name); ?> - <?php echo $__env->yieldContent('title'); ?></title>
	<!-- FAVICONS ICON -->
<link rel="shortcut icon" type="image/png" href="<?php echo e(asset($setting->icon)); ?>">
<?php /**PATH F:\laragon\www\custom-rbac-laravel\resources\views/partials/header.blade.php ENDPATH**/ ?>