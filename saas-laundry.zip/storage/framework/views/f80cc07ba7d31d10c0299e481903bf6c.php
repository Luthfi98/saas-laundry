<!--**********************************
    Footer start
***********************************-->
<div class="footer">
    <div class="copyright">
        
    </div>
</div>
<!--**********************************
    Footer end
***********************************-->
<?php /**PATH F:\laragon\www\saas-laundry\resources\views/partials/footer.blade.php ENDPATH**/ ?>