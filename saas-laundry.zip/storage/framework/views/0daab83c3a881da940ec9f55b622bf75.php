

<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <div class="d-flex justify-content-between mb-3">
                        <div>
                            <!-- Add your buttons here -->
                        </div>
                        <div>
                            <?php if($general->canAccess('module-service-create', true)): ?>
                            <a href="<?php echo e(route('tenant.services.create', ['code' => request()->route('code')])); ?>" class="btn btn-primary btn-sm" title="Create">
                                <span class="fa fa-plus"></span> Add Service
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <table class="display table" id="data-table" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Code</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Branch</th>
                                <th>Price</th>
                                <th>Unit</th>
                                <th>Status</th>
                                <th width="105px">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<!-- Datatable -->
<link href="<?php echo e(asset('cms/vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Datatable -->
<script src="<?php echo e(asset('cms/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('cms/js/plugins-init/datatables.init.js')); ?>"></script>

<script type="text/javascript">
    $(function () {
        var table = $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('tenant.services.index', ['code' => request()->route('code')])); ?>",
            columns: [
                {
                    data: 'id',
                    name: 'id',
                    orderable: false,
                    render: function(data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                },
                {data: 'code', name: 'code'},
                {data: 'name', name: 'name'},
                {data: 'category_name', name: 'category.name'},
                {data: 'branch_name', name: 'branch.name'},
                {data: 'price', name: 'price', render: function(data) {
                    return 'Rp ' + parseFloat(data).toLocaleString('id-ID');
                }},
                {data: 'unit', name: 'unit'},
                {data: 'is_active', name: 'is_active', render: function(data) {
                    return data ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>';
                }},
                {data: 'action', name: 'action', orderable: false, searchable: false, className: 'text-center'},
            ],
            language: {
                paginate: {
                    next: '<i class="fa-solid fa-angle-right"></i>',
                    previous: '<i class="fa-solid fa-angle-left"></i>'
                },
            },
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.tenant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\saas-laundry\resources\views/tenant/services/index.blade.php ENDPATH**/ ?>