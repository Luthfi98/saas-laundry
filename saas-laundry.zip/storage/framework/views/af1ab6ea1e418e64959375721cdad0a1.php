<!--**********************************
    Sidebar start
***********************************-->
<div class="deznav">
    <div class="deznav-scroll">

        <ul class="metismenu" id="menu">
            <?php $__currentLoopData = $general->getMenu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($menu->is_label): ?>
                    <li class="menu-title"><?php echo e(strtoupper($menu->name)); ?></li>
                    <?php $__currentLoopData = $menu->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($child->path == '#'): ?>
                            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                                <div class="menu-icon">
                                    <span class="<?php echo e($child->icon); ?>"></span>
                                </div>
                                <span class="nav-text"><?php echo e($child->name); ?></span>
                                </a>
                                <ul aria-expanded="false">
                                    <?php $__currentLoopData = $child->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($subchild->path == '#' ? '#' : route($subchild->path)); ?>"><?php echo e($subchild->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li><a href="<?php echo e($child->path == '#' ? '#' : route($child->path)); ?>" class="" aria-expanded="false">
                                <div class="menu-icon">
                                    <span class="<?php echo e($child->icon); ?>"></span>
                                </div>
                                    <span class="nav-text"><?php echo e($child->name); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php if($menu->path == '#'): ?>
                        <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                            <div class="menu-icon">
                                <span class="<?php echo e($menu->icon); ?>"></span>
                            </div>
                            <span class="nav-text"><?php echo e($menu->name); ?></span>
                            </a>
                            <ul aria-expanded="false">
                                <?php $__currentLoopData = $menu->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($child->path == '#'): ?>
                                    <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                                        <div class="menu-icon">
                                            <span class="<?php echo e($child->icon); ?>"></span>
                                        </div>
                                        <span class="nav-text"><?php echo e($child->name); ?></span>
                                        </a>
                                        <ul aria-expanded="false">
                                            <?php $__currentLoopData = $child->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li style="margin-left: 25px !important"><a href="<?php echo e($subchild->path == '#' ? '#' : route($subchild->path)); ?>"><?php echo e($subchild->name); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                <?php else: ?>
                                    <li><a href="<?php echo e($child->path == '#' ? '#' : route($child->path)); ?>" class="" aria-expanded="false">
                                        <div class="menu-icon">
                                            <span class="<?php echo e($child->icon); ?>"></span>
                                        </div>
                                            <span class="nav-text"><?php echo e($child->name); ?></span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li><a href="<?php echo e($menu->path == '#' ? '#' : route($menu->path)); ?>" class="" aria-expanded="false">
                            <div class="menu-icon">
                                <span class="<?php echo e($menu->icon); ?>"></span>
                            </div>
                                <span class="nav-text"><?php echo e($menu->name); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                    <hr style="margin:0.5rem 0">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>

<!--**********************************
    Sidebar end
***********************************-->
<?php /**PATH F:\laragon\www\custom-rbac-laravel\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>