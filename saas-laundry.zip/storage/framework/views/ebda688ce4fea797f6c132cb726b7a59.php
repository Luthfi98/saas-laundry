<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header">
                <h4 class="card-title mb-0">Tenant Details</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <!-- Column 1 -->
                    <div class="col-md-4">
                        <div class="mb-3 border-bottom pb-2">
                            <h6 class="mb-1"><strong>Code</strong></h6>
                            <p class="text-muted mb-0"><?php echo e($tenant->code); ?></p>
                        </div>
                        <div class="mb-3 border-bottom pb-2">
                            <h6 class="mb-1"><strong>Name</strong></h6>
                            <p class="text-muted mb-0"><?php echo e($tenant->name); ?></p>
                        </div>
                    </div>

                    <!-- Column 2 -->
                    <div class="col-md-4">
                        <div class="mb-3 border-bottom pb-2">
                            <h6 class="mb-1"><strong>Email</strong></h6>
                            <p class="text-muted mb-0"><?php echo e($tenant->email); ?></p>
                        </div>
                        <div class="mb-3 border-bottom pb-2">
                            <h6 class="mb-1"><strong>Phone</strong></h6>
                            <p class="text-muted mb-0"><?php echo e($tenant->phone); ?></p>
                        </div>
                    </div>

                    <!-- Column 3 -->
                    <div class="col-md-4">
                        <div class="mb-3 border-bottom pb-2">
                            <h6 class="mb-1"><strong>Address</strong></h6>
                            <p class="text-muted mb-0"><?php echo e($tenant->address); ?></p>
                        </div>
                        <div class="mb-3">
                            <h6 class="mb-1"><strong>Logo</strong></h6>
                            <img src="<?php echo e(asset($tenant->logo)); ?>" alt="Logo" class="img-fluid border rounded shadow-sm mt-1" style="max-height: 100px;">
                        </div>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-md-12">
                        <div class="border-top pt-3">
                            <h6 class="mb-1"><strong>Status</strong></h6>
                            <p class="text-muted mb-0">
                                <?php if(strtolower($tenant->status) === 'active'): ?>
                                    <span class="badge badge-sm bg-success"><?php echo e($tenant->status); ?></span>
                                <?php elseif(strtolower($tenant->status) === 'inactive'): ?>
                                    <span class="badge badge-sm bg-secondary"><?php echo e($tenant->status); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-sm bg-warning text-dark"><?php echo e($tenant->status); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(route('tenants.index')); ?>" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left me-1"></i> Back
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\saas-laundry\resources\views/cms/tenants/show.blade.php ENDPATH**/ ?>