<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <form method="POST" action="<?php echo e(route('subscriptions.update', $subscription->id)); ?>">
                <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group mt-3">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="name" value="<?php echo e(old('name', $subscription->name)); ?>" placeholder="Enter name" class="form-control" required>
                        </div>

                        <div class="form-group mt-3">
                            <label for="price">Price</label>
                            <input type="number" name="price" id="price" value="<?php echo e(old('price', $subscription->price)); ?>" placeholder="Enter price" class="form-control" required>
                        </div>

                        <div class="form-group mt-3">
                            <label for="branch_limit">Branch Limit</label>
                            <input type="number" name="branch_limit" id="branch_limit" value="<?php echo e(old('branch_limit', $subscription->branch_limit)); ?>" placeholder="Enter branch limit" class="form-control" required>
                        </div>

                        <div class="form-group mt-3">
                            <label for="user_limit">User Limit</label>
                            <input type="number" name="user_limit" id="user_limit" value="<?php echo e(old('user_limit', $subscription->user_limit)); ?>" placeholder="Enter user limit" class="form-control" required>
                        </div>

                        <div class="form-group mt-3">
                            <label for="features">Features</label>
                            <textarea name="features" class="form-control" id="features" cols="30" rows="10" placeholder="Enter features"><?php echo e(old('features', $subscription->features)); ?></textarea>
                        </div>

                        <div class="form-group mt-3">
                            <label for="duration_in_days">Duration in Days</label>
                            <input type="number" name="duration_in_days" id="duration_in_days" value="<?php echo e(old('duration_in_days', $subscription->duration_in_days)); ?>" placeholder="Enter duration in days" class="form-control" required>
                        </div>

                        <div class="form-group mt-3">
                            <label for="status">Status</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="status" name="status" value="active" <?php echo e(old('status', $subscription->status) == 'active' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="status"><?php echo e(old('status', $subscription->status) == 'active' ? 'Active' : 'Inactive'); ?></label>
                            </div>
                        </div>

                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('subscriptions.index')); ?>" class="btn btn-secondary"><?php echo e(__('Back')); ?></a>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\saas-laundry\resources\views/cms/subscriptions/edit.blade.php ENDPATH**/ ?>