<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('menus.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group mt-3">
                            <label for="parent">Parent Menu:</label>
                            <select name="parent" id="parent" class="form-control select2">
                                <option value="">Select Parent</option>
                                <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(old('parent', '') == $parentMenu->id ? 'selected' : ''); ?> value="<?php echo e($parentMenu->id); ?>"><?php echo e($parentMenu->name); ?></option>
                                    <?php $__currentLoopData = $parentMenu->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(old('parent', '') == $childMenu->id ? 'selected' : ''); ?> value="<?php echo e($childMenu->id); ?>">- <?php echo e($childMenu->name); ?></option>
                                        <?php $__currentLoopData = $childMenu->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subChildMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('parent', '') == $subChildMenu->id ? 'selected' : ''); ?> value="<?php echo e($subChildMenu->id); ?>">-- <?php echo e($subChildMenu->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group mt-3">
                                    <label for="name">Name:</label>
                                    <input type="text" value="<?php echo e(old('name', '')); ?>" name="name" id="name" class="form-control" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group mt-3">
                                    <label for="module">Module:</label>
                                    <input type="text" value="<?php echo e(old('module', '')); ?>" name="module" id="module" class="form-control" required>
                                    <?php $__errorArgs = ['module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>


                        <div class="form-group mt-3">
                            <label for="path">Path:</label>
                            <input type="text" value="<?php echo e(old('path', '')); ?>" name="path" id="path" class="form-control" required>
                            <?php $__errorArgs = ['path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mt-3">
                            <label for="icon">Icon:</label>
                            <div class="input-group mb-2">
                                <div class="input-group-text"><span id="show-icon"></span></div>
                                <input type="text" class="form-control" id="icon" value="<?php echo e(old('icon', '')); ?>" name="icon" required>
                            </div>
                            <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                            <div class="col-lg-6 col-md 6 col-12">
                                <div class="form-group mt-3">
                                    <label for="type">Type:</label> <br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" <?php echo e(old('type', 'cms', ) == 'cms' ? 'checked' : ''); ?> type="radio" name="type" id="cms" value="cms">
                                        <label class="form-check-label" for="cms">CMS</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" <?php echo e(old('type', '') == 'landing' ? 'checked' : ''); ?> name="type" id="landing" value="landing">
                                        <label class="form-check-label" for="landing">Landing</label>
                                    </div>
                                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md 6 col-12">
                                <div class="form-group mt-3">
                                    <label for="is_label">Is Label:</label> <br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" <?php echo e(old('is_label', '') ? 'checked' : ''); ?> name="is_label" id="is_label">
                                        <label class="form-check-label" for="is_label" <?php echo e(old('is_label', '') ? 'checked' : ''); ?> id="text-is-label">No</label>
                                    </div>
                                    <?php $__errorArgs = ['is_label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group mt-3">
                            <label for="permissions[]">Permissions:</label>
                            <select name="permissions[]" id="permissions[]" multiple class="form-control select2-multiple">
                                <option value="" disabled>Select Permissions</option>
                                <?php $__currentLoopData = $listAccess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option <?php echo e(in_array($access, old('permissions', [])) ? 'selected' : ''); ?> value="<?php echo e($access); ?>" ><?php echo e($access); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mt-3">
                            <a href="<?php echo e(route('menus.index')); ?>" class="btn btn-secondary"><?php echo e(__('Back')); ?></a>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Create')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('cms/vendor/select2/css/select2.min.css')); ?> ">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('cms/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('cms/vendor/select2/js/select2.full.min.js')); ?>"></script>
<script type="text/javascript">
    $(".select2").select2();
    $(".select2-multiple").select2();

    $("#icon").change(function(){
        var icon = $(this).val()
        $("#show-icon").addClass(icon)
    })

    $("#is_label").on("change", function() {
        if ($(this).prop("checked")) {
            $("#text-is-label").text("Yes");
        } else {
            $("#text-is-label").text("No");
        }
    });

    $("#name").keyup(function(){
        var name = $(this).val();
        name = name.toLowerCase();
        name = name.replace('module', '');
        name = name.replace(/[^a-zA-Z0-9]+/g, '-');
        $("#module").val(`module-${name}`)
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/cms/menus/create.blade.php ENDPATH**/ ?>