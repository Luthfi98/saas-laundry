<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12">
        <div class="clearfix">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo e($activity->description); ?></h4>
                </div>
                <div class="card-body">
                    <table class="table" width="100%">
                        <tr>
                            <th width="29%">User</th>
                            <th width="1%">:</th>
                            <td><?php echo e($activity->user->fullname); ?></td>
                        </tr>
                        <tr>
                            <th width="29%">IP</th>
                            <th width="1%">:</th>
                            <td><?php echo e($activity->ip); ?></td>
                        </tr>
                        <tr>
                            <th width="29%">URL</th>
                            <th width="1%">:</th>
                            <td><?php echo e($activity->url); ?></td>
                        </tr>
                        <tr>
                            <th width="29%">Date</th>
                            <th width="1%">:</th>
                            <td><?php echo e(date('d-m-Y H:i:s', strtotime($activity->created_at))); ?></td>
                        </tr>
                        <tr>
                            <th width="29%">Data</th>
                            <th width="1%">:</th>
                            <td>
                                <?php echo $data; ?>

                                
                                </ul>
                            </td>
                        </tr>

                    </table>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('report-activity-user')); ?>" class="btn btn-secondary"><?php echo e(__('Back')); ?></a>

                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/cms/activities/detail.blade.php ENDPATH**/ ?>