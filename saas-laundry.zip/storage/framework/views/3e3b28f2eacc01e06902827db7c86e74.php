<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-7 col-lg-6 col-sm-12 order-sm-2 order-xl-1 order-lg-1 ">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <div class="d-flex justify-content-between mb-3">
                            <div>
                                <!-- Add your buttons here -->
                            </div>
                            <div>

                            </div>
                        </div>
                        <table class="display table" id="data-table" width="100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Name</th>
                                    <th>Symbol</th>
                                    <th width="105px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php if($general->canAccess('module-unit-create', true)): ?>
            <div class="col-xl-5 col-lg-6 col-sm-12 order-sm-1 order-xl-2 order-lg-2 ">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Form Unit</h5>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('units.store')); ?>" id="forms" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" id="id" value="">
                                <div class="form-group mb-3">
                                    <label for="name">Name</label>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="Input Unit Name .. ">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="symbol">Symbol</label>
                                    <input type="text" name="symbol" id="symbol" class="form-control" placeholder="Input Unit Symbol .. ">
                                    <?php $__errorArgs = ['symbol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <?php if($general->canAccess('module-unit-create', true)): ?>
                                    <button type="reset" class="btn btn-secondary btn-sm" title="Reset"><span class="fa fa-disk"></span> <?php echo e(__("Reset")); ?></a>
                                    <button type="button" id="btn-submit" onclick="saveButton()" class="btn btn-primary btn-sm" title="Save"><span class="fa fa-disk"></span> <?php echo e(__("Save Unit")); ?></a>
                                <?php endif; ?>
                            </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<!-- Datatable -->
<link href="<?php echo e(asset('cms/vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Datatable -->
<script src="<?php echo e(asset('cms/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('cms/js/plugins-init/datatables.init.js')); ?>"></script>


<script type="text/javascript">
    $(function () {
        var table = $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('units.index')); ?>",
            columns: [
                {
                    data: 'id',
                    name: 'id', orderable: false,
                    render: function(data, type, row, meta) {
                        var continuousIndex = meta.row + meta.settings._iDisplayStart + 1;
                        return continuousIndex;
                    }
                },
                {data: 'name', name: 'name'},
                {data: 'symbol', name: 'symbol'},
                {data: 'action', name: 'action', orderable: false, searchable: false, className: 'text-center'},
            ],
            language: {
                paginate: {
                    next: '<i class="fa-solid fa-angle-right"></i>',
                    previous: '<i class="fa-solid fa-angle-left"></i>'
                },
            },
        });
    });

    // Pindahkan fungsi editButton ke luar
    function editButton(button) {
        var id = $(button).data('id');
        var name = $(button).data('name');
        var symbol = $(button).data('symbol');

        $('#id').val(id);
        $('#name').val(name);
        $('#symbol').val(symbol);
    }


    function saveButton() {
        var formData = {
            id: $('#id').val(),
            name: $('#name').val(),
            symbol: $('#symbol').val(),
            _token: $('input[name="_token"]').val()
        };

        var url = formData.id ? "<?php echo e(route('units.update', '')); ?>/" + formData.id : "<?php echo e(route('units.store')); ?>";
        var method = formData.id ? "PUT" : "POST";

        $.ajax({
            url: url,
            type: method,
            data: formData,
            dataType: "json",
            success: function(response) {
                if (response.success) {
                    toastSuccess(response.message);
                    $('#forms')[0].reset();
                    $('#id').val('');
                    $('#data-table').DataTable().ajax.reload();
                    $('.is-invalid').removeClass('is-invalid');
                    $('.invalid-feedback').remove();
                } else {
                    toastWarning(response.message);
                }
            },
            error: function(xhr) {
                var errors = xhr.responseJSON.errors;
                $('.is-invalid').removeClass('is-invalid');
                $('.invalid-feedback').remove();

                $.each(errors, function(key, value) {
                    var input = $('[name="' + key + '"]');
                    input.addClass('is-invalid');
                    input.after('<div class="invalid-feedback">' + value[0] + '</div>');
                });

                // toastWarning('Periksa kembali input yang salah.');
            }
        });




    }

    function deleteData(id) {
        $.ajax({
            url: "<?php echo e(route('units.destroy', '')); ?>/" + id,
            type: "DELETE",
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                _method: "DELETE"
            },
            success: function(response) {
                if (response.success) {
                    toastSuccess(response.message);
                    $('#data-table').DataTable().ajax.reload();
                } else {
                    toastWarning(response.message);

                }
            },
            error: function(xhr) {
                toastWarning('Something went wrong!');
            }
        });
    }
  </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\custom-rbac-laravel\resources\views/cms/units/index.blade.php ENDPATH**/ ?>